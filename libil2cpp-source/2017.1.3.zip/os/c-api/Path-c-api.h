#pragma once

#if defined(__cplusplus)
extern "C"
{
#endif

char* UnityPalGetExecutablePath();
char* UnityPalGetTempPath();

#if defined(__cplusplus)
}
#endif
