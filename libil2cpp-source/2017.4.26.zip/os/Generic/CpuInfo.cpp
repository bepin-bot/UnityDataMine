#include "il2cpp-config.h"

#if NET_4_0
#if IL2CPP_USE_GENERIC_CPU_INFO

#include "os/CpuInfo.h"

namespace il2cpp
{
namespace os
{
    void* CpuInfo::Create()
    {
        return NULL;
    }

    int32_t CpuInfo::Usage(void* previous)
    {
        return 0;
    }
}
}

#endif
#endif
