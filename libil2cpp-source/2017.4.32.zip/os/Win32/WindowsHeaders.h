#pragma once

#if IL2CPP_TARGET_WINDOWS

#include "../c-api/Win32/WindowsHeaders.h"

#endif
