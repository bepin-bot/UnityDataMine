#pragma once

#if NET_4_0

bool worker_try_create();

#endif // NET_4_0
