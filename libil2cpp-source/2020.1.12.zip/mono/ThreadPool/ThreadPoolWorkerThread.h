#pragma once

bool worker_try_create();
