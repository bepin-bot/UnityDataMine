#include "il2cpp-config.h"

#if IL2CPP_TARGET_WINDOWS

#include <cassert>
#include "os/FileSystemWatcher.h"

namespace il2cpp
{
namespace os
{
namespace FileSystemWatcher
{
    int IsSupported()
    {
        IL2CPP_NOT_IMPLEMENTED_ICALL(FileSystemWatcher::IsSupported);
        return 0;
    }
}
}
}

#endif
