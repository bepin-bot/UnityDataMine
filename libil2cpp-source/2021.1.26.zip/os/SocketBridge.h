#pragma once
#include "il2cpp-config.h"

namespace il2cpp
{
namespace os
{
    class LIBIL2CPP_CODEGEN_API SocketBridge
    {
    public:
        static void WaitForInitialization();
    };
}
}
