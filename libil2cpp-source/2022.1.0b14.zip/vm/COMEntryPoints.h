#pragma once

namespace il2cpp
{
namespace vm
{
    struct LIBIL2CPP_CODEGEN_API COMEntryPoints
    {
        static void FreeCachedData();
    };
}
}
