#pragma once
#include "il2cpp-config.h"
#include <string>

typedef uint16_t Il2CppChar;
typedef std::basic_string<Il2CppChar> UTF16String;