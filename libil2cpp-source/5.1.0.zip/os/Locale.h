#pragma once

#include <stdint.h>
#include <string>

namespace il2cpp
{
namespace os
{

class Locale
{
public:
	static std::string GetLocale();
};

} /* namespace os */
} /* namespace il2cpp */