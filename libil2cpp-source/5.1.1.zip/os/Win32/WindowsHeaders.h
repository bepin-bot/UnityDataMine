#pragma once

#if IL2CPP_TARGET_WINDOWS || IL2CPP_TARGET_XBOXONE

#define WIN32_LEAN_AND_MEAN 1
#include <Windows.h>

#endif
