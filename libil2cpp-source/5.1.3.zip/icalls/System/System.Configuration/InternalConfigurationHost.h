#pragma once

struct Il2CppString;

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace System
{
namespace Configuration
{

class InternalConfigurationHost
{
public:
	static Il2CppString* get_bundled_machine_config ();
};

} /* namespace Configuration */
} /* namespace System */
} /* namespace System */
} /* namespace icalls */
} /* namespace il2cpp */
