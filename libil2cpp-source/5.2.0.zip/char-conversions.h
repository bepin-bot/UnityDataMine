#pragma once

extern uint8_t CategoryData_v4 [71680];
extern uint8_t NumericData [12938];
extern double NumericDataValues [58];
extern uint16_t ToLowerDataLow [9424];
extern uint16_t ToLowerDataHigh [223];
extern uint16_t ToUpperDataLow [9450];
extern uint16_t ToUpperDataHigh [223];
