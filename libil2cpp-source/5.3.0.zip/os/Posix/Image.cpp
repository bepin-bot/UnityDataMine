#include "il2cpp-config.h"

#if IL2CPP_TARGET_JAVASCRIPT || IL2CPP_TARGET_LINUX || IL2CPP_TARGET_ANDROID


namespace il2cpp
{
namespace os
{

namespace Image
{

void* GetImageBase()
{
	return NULL;
}

}
}
}

#endif
