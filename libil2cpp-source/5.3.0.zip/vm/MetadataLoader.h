#pragma once

namespace il2cpp
{
namespace vm
{

class MetadataLoader
{
public:
	static void* LoadMetadataFile (const char* fileName);
};

} // namespace vm
} // namespace il2cpp
