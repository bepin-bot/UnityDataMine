#pragma once

#include <stdint.h>

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{

class Double
{
public:
	static bool ParseImpl (char *,double *);
};

} /* namespace System */
} /* namespace mscorlib */
} /* namespace icalls */
} /* namespace il2cpp */
