#include "il2cpp-config.h"

#if IL2CPP_TARGET_WINRT

#include "os/Locale.h"

namespace il2cpp
{
namespace os
{

std::string Locale::GetLocale()
{
	NOT_IMPLEMENTED_NO_ASSERT(Locale::GetLocale, "TODO: implement properly");
	return "en-US";
}

} /* namespace os */
} /* namespace il2cpp */

#endif