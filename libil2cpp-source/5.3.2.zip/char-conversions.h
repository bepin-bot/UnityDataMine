#pragma once

extern const uint8_t CategoryData_v4 [71680];
extern const uint8_t NumericData [12938];
extern const double NumericDataValues [58];
extern const uint16_t ToLowerDataLow [9424];
extern const uint16_t ToLowerDataHigh [223];
extern const uint16_t ToUpperDataLow [9450];
extern const uint16_t ToUpperDataHigh [223];
