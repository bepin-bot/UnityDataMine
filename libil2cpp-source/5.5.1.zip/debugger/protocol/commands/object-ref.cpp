#if IL2CPP_DEBUGGER_ENABLED

#include "object-ref.h"

using namespace il2cpp::debugger;

#endif
