#if IL2CPP_DEBUGGER_ENABLED

#include "assembly.h"

using namespace il2cpp::debugger;

#endif
