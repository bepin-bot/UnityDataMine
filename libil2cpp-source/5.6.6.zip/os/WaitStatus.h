#pragma once

namespace il2cpp
{
namespace os
{
    enum WaitStatus
    {
        kWaitStatusSuccess = 0,
        kWaitStatusFailure,
        kWaitStatusTimeout,
    };
}
}
